from tkinter import *
a=Label()