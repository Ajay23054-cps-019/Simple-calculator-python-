def res(a,c,b):
    if(c=="+"):
        return a+b
    elif(c=="-"):
        return a-b
    elif(c=="*"):
        return a*b
    elif(c=="/"):
        return a/b
    else:
        return "Enter correct symbol"